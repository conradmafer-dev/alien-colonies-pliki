extends Node
const Host = preload("res://TestHost.gd")
const FakeGoogle = preload("res://FakeGoogle.gd")
const FakeEmail = preload("res://FakeEmail.gd")
var checks: int = 0
var failures: Array[String] = []
var layouts: Array[Dictionary] = []
var host
func expect(ok: bool, message: String) -> void:
    checks += 1
    if not ok:
        failures.append(message)
        push_error(message)
func _ready() -> void:
    run.call_deferred()
func frames(count: int = 5) -> void:
    for _i: int in range(count):
        await get_tree().process_frame
func setup_host(language: String, viewport: Vector2i) -> void:
    get_tree().root.size = viewport
    I18n.set_locale(language, false)
    host = Host.new()
    get_tree().root.add_child(host)
    host.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    host.theme = host._make_theme()
    host._make_login()
    host.app_screen = MarginContainer.new()
    host.add_child(host.app_screen)
    host.race_screen = MarginContainer.new()
    host.add_child(host.race_screen)
    host.server_url = ""
    host.google_login = FakeGoogle.new()
    host.google_login.setup(host)
    host.google_login.configuration_changed.connect(host._on_google_configuration)
    host.google_login.changed.connect(host._refresh_google_controls)
    host.google_login.needs_name.connect(host._on_google_name_needed)
    host.google_login.completed.connect(host._on_google_completed)
    host.google_login.failed.connect(host._on_google_failed)
    host.google_login.cancelled.connect(host._on_google_cancelled)
    host.email_login = FakeEmail.new()
    host.email_login.setup(host)
    host.email_login.configuration_changed.connect(host._refresh_email_controls)
    host.email_login.changed.connect(host._refresh_email_controls)
    host.email_login.needs_name.connect(host._on_email_name_needed)
    host.email_login.completed.connect(host._on_email_completed)
    host.email_login.failed.connect(host._on_email_failed)
    host.google_login._set_configuration(true, true)
    host.email_login._set_configuration(true)
    host._sync_screen_visibility()
    await frames()
func dispose() -> void:
    # Disconnect UI callbacks before destroying its widgets. Transport shutdown
    # is exercised separately while the UI is still alive.
    for provider in [host.google_login, host.email_login]:
        for signal_info: Dictionary in provider.get_signal_list():
            for entry: Dictionary in provider.get_signal_connection_list(signal_info.name):
                provider.disconnect(signal_info.name, entry.callable)
    host.queue_free()
    await frames(2)
func assert_name_stage(prefix: String) -> void:
    expect(host.login_name_panel.is_visible_in_tree(), prefix + " name panel visible")
    expect(host.login_form.is_visible_in_tree(), prefix + " name form visible")
    expect(not host.login_choice_panel.is_visible_in_tree(), prefix + " chooser hidden")
    for control: Control in [host.google_login_button, host.email_login_button, host.create_account_button, host.email_form, host.login_hero_spacer, host.login_announcement.panel, host.login_version_label, host.google_cancel_button, host.login_retry_button]:
        expect(not control.is_visible_in_tree(), prefix + " old content hidden: " + str(control.name))
    expect(host.name_field.is_visible_in_tree() and host.login_submit.is_visible_in_tree() and host.login_name_cancel.is_visible_in_tree(), prefix + " all name actions visible")
    expect(not host.password_field.is_visible_in_tree() and not host.repeat_password_field.is_visible_in_tree(), prefix + " no password fields")
func assert_choice(prefix: String) -> void:
    expect(host.login_mode == "", prefix + " empty mode")
    expect(not host.login_name_panel.is_visible_in_tree(), prefix + " name panel hidden")
    expect(host.login_choice_panel.is_visible_in_tree(), prefix + " chooser visible")
    expect(host.google_login_button.is_visible_in_tree() and host.email_login_button.is_visible_in_tree() and host.create_account_button.is_visible_in_tree(), prefix + " login buttons restored")
    expect(not host.email_form.is_visible_in_tree(), prefix + " no automatic email form")
func response(race: String) -> Dictionary:
    return {"ok": true, "token": "synthetic_session_86", "state": {"player": {"id": "test_player", "name": "Test Empire", "race_id": race}, "races": [{"id": "zetans"}]}}
func announcement_reply() -> void:
    host.login_announcement._on_response(HTTPRequest.RESULT_SUCCESS, 200, PackedStringArray(), JSON.stringify({"visible": true, "announcement": {"title": "Test", "body": "Synthetic announcement"}}).to_utf8_buffer(), host.login_announcement._generation)
func run() -> void:
    for language: String in ["pl", "en"]:
        for viewport: Vector2i in [Vector2i(720, 960), Vector2i(720, 1280), Vector2i(800, 480), Vector2i(640, 360), Vector2i(960, 640)]:
            await setup_host(language, viewport)
            for provider_key: String in ["google", "email"]:
                var provider = host.google_login if provider_key == "google" else host.email_login
                var prefix: String = language + " " + str(viewport) + " " + provider_key
                host.email_entry_open = provider_key == "email"
                announcement_reply()
                host.login_scroll.scroll_vertical = 9999
                provider.verified("needs_name")
                await frames(8)
                assert_name_stage(prefix)
                expect(host.login_form_title.text == ("Tworzenie imperium" if language == "pl" else "Create an empire"), prefix + " translated title")
                expect(host.login_submit.text == ("Stwórz imperium" if language == "pl" else "Create empire"), prefix + " translated CTA")
                expect(host.login_name_cancel.text == ("Anuluj" if language == "pl" else "Cancel"), prefix + " translated cancel")
                expect(not host._language_change_safe(), prefix + " active proof prevents language reconstruction")
                var view: Rect2 = Rect2(Vector2.ZERO, Vector2(viewport))
                for control: Control in [host.login_form_title, host.name_field, host.login_submit, host.login_name_cancel]:
                    var rect: Rect2 = control.get_global_rect()
                    expect(view.encloses(rect), prefix + " fits viewport without scrolling: " + str(control.name) + " " + str(rect))
                expect(host.login_scroll.scroll_vertical == 0, prefix + " initial stage scroll at top")
                expect(host.login_name_panel.get_global_rect().position.y <= 22, prefix + " independent panel starts at top")
                var before: Rect2 = host.login_name_panel.get_global_rect()
                await frames(10)
                expect(before == host.login_name_panel.get_global_rect(), prefix + " stable responsive layout")
                # Android's safe-area/keyboard margins are owned by the existing
                # _update_mobile_margins logic. Resizing the stage must preserve them.
                var insets: Dictionary = {"left": 30, "top": 42, "right": 28, "bottom": 120}
                for side: String in insets:
                    host.login_margin.add_theme_constant_override("margin_" + side, insets[side])
                host._update_login_art_layout()
                await frames()
                for side: String in insets:
                    expect(host.login_margin.get_theme_constant("margin_" + side) == insets[side], prefix + " preserves mobile inset " + side)
                for side: String in insets:
                    host.login_margin.add_theme_constant_override("margin_" + side, 22)
                await frames()
                layouts.append({"language": language, "viewport": str(viewport), "provider": provider_key, "panel": str(before), "field": str(host.name_field.get_global_rect()), "submit": str(host.login_submit.get_global_rect()), "cancel": str(host.login_name_cancel.get_global_rect())})
                host.name_field.text = "Test Empire"
                var proof: Dictionary = provider._proof().duplicate(true)
                host._submit_login_form()
                expect(provider.phase == "completing" and provider.sent.back().payload.get("name") == "Test Empire", prefix + " name submitted via real controller")
                expect(host.login_submit.disabled, prefix + " completion disables duplicate submit")
                assert_name_stage(prefix + " completing")
                provider.reply("complete", {"ok": false, "error": "Wybierz inną nazwę imperium."}, 409)
                await frames()
                expect(host.name_field.text == "Test Empire" and provider._proof() == proof, prefix + " 409 preserves name and proof")
                expect(not host.login_submit.disabled and host.login_notice.is_visible_in_tree(), prefix + " conflict can be corrected")
                var message: String = host.login_message.text
                host.google_login._set_configuration(false, false)
                host.email_login._set_configuration(false)
                announcement_reply()
                host.google_login._set_configuration(true, true)
                host.email_login._set_configuration(true)
                provider.needs_name.emit()
                await frames()
                assert_name_stage(prefix + " late callbacks")
                expect(host.name_field.text == "Test Empire" and host.login_message.text == message, prefix + " refresh preserves name and error")
                expect(provider._proof() == proof, prefix + " refresh preserves proof")
                host.name_field.text = "ab"
                var sent_count: int = provider.sent.size()
                host._submit_login_form()
                expect(provider.sent.size() == sent_count and provider.waiting_for_name(), prefix + " local length error stays in stage")
                host.name_field.text = "Valid Empire"
                host._submit_login_form()
                provider.reply("complete", {"ok": false, "error": "Wybierz inną nazwę imperium."}, 400)
                expect(host.name_field.text == "Valid Empire" and provider._proof() == proof, prefix + " 400 preserves name and proof")
                host.login_name_cancel.pressed.emit()
                await frames()
                assert_choice(prefix + " cancel")
                expect(provider._flow_id.is_empty() and provider._poll_secret.is_empty() and host.name_field.text.is_empty(), prefix + " cancel clears flow and name")
                provider.verified("needs_name")
                provider._deadline.timeout.emit()
                await frames()
                assert_choice(prefix + " expired")
                expect(host.login_message_error, prefix + " expiry visible")
                provider.verified("needs_name")
                provider.cancel()
                await frames()
                assert_choice(prefix + " silent cancel")
                expect(host.login_message.text == I18n.t("Potwierdzenie logowania wygasło. Zaloguj się ponownie."), prefix + " abandoned flow explained")
            await dispose()
        # Full success/error lifecycle needs one viewport per locale, not every size.
        for provider_key: String in ["google", "email"]:
            for status: String in ["needs_name", "ready"]:
                await setup_host(language, Vector2i(720, 960))
                var provider = host.google_login if provider_key == "google" else host.email_login
                var prefix: String = language + " " + provider_key + " success " + status
                provider.verified(status)
                if status == "needs_name":
                    host.name_field.text = "New Empire"
                    host.login_submit.pressed.emit()
                expect(provider.phase == "completing", prefix + " controller auto-completes existing accounts")
                provider.reply("complete", response("" if status == "needs_name" else "zetans"))
                expect(host.session_token == "synthetic_session_86" and host.applied_states == 1, prefix + " real auth handler accepts session")
                expect(not host.showing_login and not host.login_screen.visible and host.login_mode == "", prefix + " complete exits login atomically")
                expect(host.race_screen.visible == (status == "needs_name"), prefix + " new empire reaches race selection")
                expect(host.app_screen.visible == (status == "ready"), prefix + " existing empire goes directly to game")
                await frames()
                expect(not host.login_screen.visible and host.login_mode == "", prefix + " deferred callback cannot restore login")
                host._logout()
                await frames()
                assert_choice(prefix + " logout")
                host.session_token = "synthetic_expired_session"
                host.showing_login = false
                host._handle_response("state", HTTPRequest.RESULT_SUCCESS, 401, JSON.stringify({"ok": false}).to_utf8_buffer())
                await frames()
                assert_choice(prefix + " session 401")
                await dispose()
            # Reauthentication never opens name creation, including wrong account.
            await setup_host(language, Vector2i(720, 960))
            var provider = host.google_login if provider_key == "google" else host.email_login
            host.showing_login = false
            host.session_token = "synthetic_previous_session"
            host.state = response("zetans").state
            host._sync_screen_visibility()
            provider.verified("needs_name", true)
            await frames()
            expect(not host.login_name_panel.visible and host.login_mode == "", language + " " + provider_key + " bound reauth rejects new empire")
            provider.verified("ready", true)
            provider.reply("complete", response("zetans"))
            expect(host.session_token == "synthetic_session_86" and not host.login_screen.visible and host.app_screen.visible, language + " " + provider_key + " existing reauth returns to game")
            await dispose()
    var result: Dictionary = {"checks": checks, "failures": failures, "layouts": layouts, "scope": "Offline real Godot UI and Google/email state machines; synthetic HTTP/native results; game rendering and persistence stubbed; no physical Android, real Google login or purchases tested."}
    var report_path: String = OS.get_environment("AC_AUTH86_REPORT_PATH")
    if report_path.is_empty():
        report_path = "res://auth_ui86_report.json"
    var file = FileAccess.open(report_path, FileAccess.WRITE)
    file.store_string(JSON.stringify(result, "  "))
    file.close()
    print("AUTH_UI86: ", checks, " checks; ", failures.size(), " failures")
    get_tree().quit(0 if failures.is_empty() else 1)
