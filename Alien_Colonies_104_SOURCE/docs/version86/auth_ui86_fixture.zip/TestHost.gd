extends "res://client/scripts/main.gd"
# Exercise the real login UI and auth response routing. Only game rendering,
# persistence and unrelated HTTP are replaced; no account or network is used.
var notifications: Array[String] = []
var applied_states: int = 0
func _ready() -> void:
    set_process(false)
func _texture(_key: String) -> Texture2D:
    return null
func _save_session() -> void:
    pass
func _apply_state_now(next_state: Dictionary, _arrived_at: int) -> void:
    applied_states += 1
    state = next_state
    showing_login = false
    _sync_screen_visibility()
func _notify(message: String, error: bool = false) -> void:
    notifications.append(message)
    if showing_login:
        _set_login_message(message, error)
func _reset_world() -> void:
    if google_login != null:
        google_login.cancel()
    if email_login != null:
        email_login.cancel()
    state = {}
func _invalidate_quote(_reset_text: bool = true) -> void:
    pass
func _end_skill_navigation() -> void:
    pass
func _revoke_logged_out_session(_origin: String, _token: String) -> void:
    pass
func _ui_interacting() -> bool:
    return false
