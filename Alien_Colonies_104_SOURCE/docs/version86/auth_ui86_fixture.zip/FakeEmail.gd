extends "res://client/scripts/email_login.gd"
var sent: Array[Dictionary] = []
func _send(kind: String, path: String, payload: Dictionary, _method: int = HTTPClient.METHOD_POST) -> void:
    _request_kind = kind
    sent.append({"kind": kind, "path": path, "payload": payload.duplicate(true)})
func reply(kind: String, payload: Dictionary, status: int = 200) -> void:
    _on_response(HTTPRequest.RESULT_SUCCESS, status, PackedStringArray(), JSON.stringify(payload).to_utf8_buffer(), _request_generation, kind)
func verified(status: String, bound: bool = false) -> void:
    cancel()
    configured = true
    configuration_loaded = true
    phase = "waiting"
    _flow_origin = str(host.server_url)
    _flow_session = str(host.session_token) if bound else ""
    _flow_player_id = str(host.state.get("player", {}).get("id", "")) if bound else ""
    _flow_id = "synthetic_email_flow_86"
    _poll_secret = "synthetic_email_proof_86"
    _handoff_ticket = "synthetic_email_handoff_86"
    _expires_at_ms = Time.get_ticks_msec() + 60000
    reply("status", {"ok": true, "status": status})
